import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CourseProgress } from '@/types';

interface ProgressState {
  progress: CourseProgress;
  updateLessonProgress: (courseId: string, progress: number) => void;
  updateQuizScore: (courseId: string, quizId: string, score: number) => void;
  markCourseCompleted: (courseId: string) => void;
  getOverallProgress: () => number;
}

export const useProgressStore = create<ProgressState>()(
  persist(
    (set, get) => ({
      progress: {},
      updateLessonProgress: (courseId: string, progress: number) => {
        set((state) => {
          const courseProgress = state.progress[courseId] || {
            completed: false,
            progress: 0,
            lastAccessed: new Date().toISOString(),
            quizScores: {},
          };
          
          return {
            progress: {
              ...state.progress,
              [courseId]: {
                ...courseProgress,
                progress,
                lastAccessed: new Date().toISOString(),
              },
            },
          };
        });
      },
      updateQuizScore: (courseId: string, quizId: string, score: number) => {
        set((state) => {
          const courseProgress = state.progress[courseId] || {
            completed: false,
            progress: 0,
            lastAccessed: new Date().toISOString(),
            quizScores: {},
          };
          
          return {
            progress: {
              ...state.progress,
              [courseId]: {
                ...courseProgress,
                quizScores: {
                  ...courseProgress.quizScores,
                  [quizId]: score,
                },
                lastAccessed: new Date().toISOString(),
              },
            },
          };
        });
      },
      markCourseCompleted: (courseId: string) => {
        set((state) => {
          const courseProgress = state.progress[courseId] || {
            completed: false,
            progress: 0,
            lastAccessed: new Date().toISOString(),
            quizScores: {},
          };
          
          return {
            progress: {
              ...state.progress,
              [courseId]: {
                ...courseProgress,
                completed: true,
                progress: 100,
                lastAccessed: new Date().toISOString(),
              },
            },
          };
        });
      },
      getOverallProgress: () => {
        const state = get();
        const courses = Object.keys(state.progress);
        
        if (courses.length === 0) return 0;
        
        const totalProgress = courses.reduce(
          (sum, courseId) => sum + state.progress[courseId].progress,
          0
        );
        
        return totalProgress / courses.length;
      },
    }),
    {
      name: 'progress-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);