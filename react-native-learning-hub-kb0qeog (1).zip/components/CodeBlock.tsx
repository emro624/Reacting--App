import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '@/constants/colors';

interface CodeBlockProps {
  code: string;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ code }) => {
  return (
    <View style={styles.container}>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.scrollContainer}
      >
        <ScrollView 
          style={styles.codeScrollView}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.code}>{code}</Text>
        </ScrollView>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1E1E2E', // Slightly different from card color for contrast
    borderRadius: 8,
    marginVertical: 12,
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  scrollContainer: {
    maxHeight: 300,
  },
  codeScrollView: {
    padding: 16,
  },
  code: {
    fontFamily: 'monospace',
    fontSize: 14,
    color: '#E4E4E7',
    lineHeight: 20,
  },
});