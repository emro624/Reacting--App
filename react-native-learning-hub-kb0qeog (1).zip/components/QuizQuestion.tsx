import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Question } from '@/types';
import { colors } from '@/constants/colors';
import { CodeBlock } from './CodeBlock';
import { Button } from './Button';
import { TextInput } from './TextInput';
import { Check, X } from 'lucide-react-native';
import { FillInBlankQuestion } from './FillInBlankQuestion';

interface QuizQuestionProps {
  question: Question;
  onAnswer: (isCorrect: boolean) => void;
}

export const QuizQuestion: React.FC<QuizQuestionProps> = ({ 
  question,
  onAnswer
}) => {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [textAnswer, setTextAnswer] = useState<string>('');
  const [showExplanation, setShowExplanation] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  
  const handleSubmit = () => {
    let correct = false;
    
    if (question.type === 'multiple-choice' || question.type === 'true-false') {
      correct = selectedAnswer === question.correctAnswer;
    } else if (question.type === 'code-completion' || question.type === 'error-detection') {
      if (Array.isArray(question.correctAnswer)) {
        // Check if any of the correct answers match
        correct = question.correctAnswer.some(answer => 
          textAnswer.toLowerCase().includes(answer.toLowerCase())
        );
      } else {
        correct = textAnswer.toLowerCase().includes(question.correctAnswer.toLowerCase());
      }
    }
    
    setIsCorrect(correct);
    setShowExplanation(true);
    onAnswer(correct);
  };
  
  const handleFillInBlankSubmit = (isCorrect: boolean) => {
    setIsCorrect(isCorrect);
    setShowExplanation(true);
    onAnswer(isCorrect);
  };
  
  const renderQuestionContent = () => {
    switch (question.type) {
      case 'fill-in-blank':
        return (
          <FillInBlankQuestion
            code={question.code || ''}
            blanks={question.blanks || []}
            onSubmit={handleFillInBlankSubmit}
          />
        );
        
      case 'multiple-choice':
        return (
          <View style={styles.optionsContainer}>
            {question.options?.map((option, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.optionButton,
                  selectedAnswer === option && styles.selectedOption,
                  showExplanation && selectedAnswer === option && !isCorrect && styles.incorrectOption,
                  showExplanation && option === question.correctAnswer && styles.correctOption,
                ]}
                onPress={() => !showExplanation && setSelectedAnswer(option)}
                disabled={showExplanation}
              >
                <Text 
                  style={[
                    styles.optionText,
                    selectedAnswer === option && styles.selectedOptionText,
                    showExplanation && selectedAnswer === option && !isCorrect && styles.incorrectOptionText,
                    showExplanation && option === question.correctAnswer && styles.correctOptionText,
                  ]}
                >
                  {option}
                </Text>
                {showExplanation && option === question.correctAnswer && (
                  <Check size={18} color={colors.dark.success} style={styles.icon} />
                )}
                {showExplanation && selectedAnswer === option && !isCorrect && (
                  <X size={18} color={colors.dark.error} style={styles.icon} />
                )}
              </TouchableOpacity>
            ))}
          </View>
        );
        
      case 'true-false':
        return (
          <View style={styles.trueFalseContainer}>
            <TouchableOpacity
              style={[
                styles.trueFalseButton,
                selectedAnswer === 'true' && styles.selectedOption,
                showExplanation && selectedAnswer === 'true' && question.correctAnswer !== 'true' && styles.incorrectOption,
                showExplanation && question.correctAnswer === 'true' && styles.correctOption,
              ]}
              onPress={() => !showExplanation && setSelectedAnswer('true')}
              disabled={showExplanation}
            >
              <Text 
                style={[
                  styles.trueFalseText,
                  selectedAnswer === 'true' && styles.selectedOptionText,
                  showExplanation && selectedAnswer === 'true' && question.correctAnswer !== 'true' && styles.incorrectOptionText,
                  showExplanation && question.correctAnswer === 'true' && styles.correctOptionText,
                ]}
              >
                True
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.trueFalseButton,
                selectedAnswer === 'false' && styles.selectedOption,
                showExplanation && selectedAnswer === 'false' && question.correctAnswer !== 'false' && styles.incorrectOption,
                showExplanation && question.correctAnswer === 'false' && styles.correctOption,
              ]}
              onPress={() => !showExplanation && setSelectedAnswer('false')}
              disabled={showExplanation}
            >
              <Text 
                style={[
                  styles.trueFalseText,
                  selectedAnswer === 'false' && styles.selectedOptionText,
                  showExplanation && selectedAnswer === 'false' && question.correctAnswer !== 'false' && styles.incorrectOptionText,
                  showExplanation && question.correctAnswer === 'false' && styles.correctOptionText,
                ]}
              >
                False
              </Text>
            </TouchableOpacity>
          </View>
        );
        
      case 'code-completion':
      case 'error-detection':
        return (
          <View style={styles.codeContainer}>
            {question.code && <CodeBlock code={question.code} />}
            <TextInput
              value={textAnswer}
              onChangeText={setTextAnswer}
              placeholder="Type your answer here..."
              multiline
              style={styles.textInput}
              editable={!showExplanation}
            />
          </View>
        );
    }
  };
  
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.questionText}>{question.question}</Text>
      
      {renderQuestionContent()}
      
      {!showExplanation && question.type !== 'fill-in-blank' && (
        <Button 
          title="Submit Answer"
          onPress={handleSubmit}
          disabled={
            (question.type === 'multiple-choice' || question.type === 'true-false') 
              ? !selectedAnswer 
              : !textAnswer.trim()
          }
          style={styles.submitButton}
        />
      )}
      
      {showExplanation && (
        <View style={styles.explanationContainer}>
          <View style={[
            styles.resultBadge,
            isCorrect ? styles.correctBadge : styles.incorrectBadge
          ]}>
            <Text style={styles.resultText}>
              {isCorrect ? 'Correct!' : 'Incorrect'}
            </Text>
          </View>
          <Text style={styles.explanationTitle}>Explanation:</Text>
          <Text style={styles.explanationText}>{question.explanation}</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  questionText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 20,
  },
  optionsContainer: {
    marginBottom: 24,
  },
  optionButton: {
    padding: 16,
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.dark.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  selectedOption: {
    borderColor: colors.dark.primary,
    backgroundColor: `${colors.dark.primary}20`,
  },
  correctOption: {
    borderColor: colors.dark.success,
    backgroundColor: `${colors.dark.success}20`,
  },
  incorrectOption: {
    borderColor: colors.dark.error,
    backgroundColor: `${colors.dark.error}20`,
  },
  optionText: {
    fontSize: 16,
    color: colors.dark.text,
    flex: 1,
  },
  selectedOptionText: {
    color: colors.dark.primary,
    fontWeight: '500',
  },
  correctOptionText: {
    color: colors.dark.success,
    fontWeight: '500',
  },
  incorrectOptionText: {
    color: colors.dark.error,
    fontWeight: '500',
  },
  trueFalseContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  trueFalseButton: {
    flex: 1,
    padding: 16,
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    marginHorizontal: 6,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  trueFalseText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.dark.text,
  },
  codeContainer: {
    marginBottom: 24,
  },
  textInput: {
    height: 120,
    textAlignVertical: 'top',
  },
  submitButton: {
    marginTop: 8,
  },
  explanationContainer: {
    marginTop: 24,
    padding: 16,
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  resultBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginBottom: 12,
  },
  correctBadge: {
    backgroundColor: `${colors.dark.success}30`,
  },
  incorrectBadge: {
    backgroundColor: `${colors.dark.error}30`,
  },
  resultText: {
    color: colors.dark.text,
    fontWeight: '600',
    fontSize: 14,
  },
  explanationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 8,
  },
  explanationText: {
    fontSize: 14,
    color: colors.dark.subtext,
    lineHeight: 20,
  },
  icon: {
    marginLeft: 8,
  },
});