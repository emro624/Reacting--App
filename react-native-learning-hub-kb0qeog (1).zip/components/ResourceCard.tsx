import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { Image } from 'expo-image';
import { ExternalLink, Youtube, BookOpen } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { Resource } from '@/types';

interface ResourceCardProps {
  resource: Resource;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({ resource }) => {
  const handlePress = async () => {
    const supported = await Linking.canOpenURL(resource.url);
    
    if (supported) {
      await Linking.openURL(resource.url);
    } else {
      console.error("Don't know how to open URI: " + resource.url);
    }
  };
  
  const getPlatformIcon = () => {
    switch (resource.platform) {
      case 'youtube':
        return <Youtube size={20} color={colors.dark.error} />;
      case 'udemy':
        return <BookOpen size={20} color="#A435F0" />;
      default:
        return <ExternalLink size={20} color={colors.dark.primary} />;
    }
  };
  
  return (
    <TouchableOpacity style={styles.card} onPress={handlePress} activeOpacity={0.9}>
      <Image
        source={{ uri: resource.image }}
        style={styles.image}
        contentFit="cover"
        transition={200}
      />
      <View style={styles.content}>
        <View style={styles.header}>
          <View style={styles.platformBadge}>
            {getPlatformIcon()}
            <Text style={styles.platformText}>{resource.platform}</Text>
          </View>
        </View>
        <Text style={styles.title}>{resource.title}</Text>
        <Text style={styles.description} numberOfLines={2}>
          {resource.description}
        </Text>
        <View style={styles.tagsContainer}>
          {resource.tags.slice(0, 3).map((tag, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  image: {
    width: '100%',
    height: 140,
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  platformBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: `${colors.dark.primary}20`,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  platformText: {
    color: colors.dark.text,
    fontSize: 12,
    fontWeight: '500',
    marginLeft: 4,
    textTransform: 'capitalize',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginBottom: 12,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  tag: {
    backgroundColor: colors.dark.background,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginRight: 8,
    marginBottom: 4,
  },
  tagText: {
    color: colors.dark.subtext,
    fontSize: 12,
  },
});