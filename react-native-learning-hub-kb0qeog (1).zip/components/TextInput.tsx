import React from 'react';
import { 
  TextInput as RNTextInput, 
  StyleSheet, 
  View, 
  Text,
  TextInputProps as RNTextInputProps,
  ViewStyle
} from 'react-native';
import { colors } from '@/constants/colors';

interface TextInputProps extends RNTextInputProps {
  label?: string;
  error?: string;
  containerStyle?: ViewStyle;
}

export const TextInput: React.FC<TextInputProps> = ({
  label,
  error,
  containerStyle,
  style,
  ...props
}) => {
  return (
    <View style={[styles.container, containerStyle]}>
      {label && <Text style={styles.label}>{label}</Text>}
      <RNTextInput
        style={[
          styles.input,
          error && styles.inputError,
          style
        ]}
        placeholderTextColor={colors.dark.subtext}
        selectionColor={colors.dark.primary}
        {...props}
      />
      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.dark.text,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.dark.card,
    borderWidth: 1,
    borderColor: colors.dark.border,
    borderRadius: 8,
    padding: 12,
    color: colors.dark.text,
    fontSize: 16,
  },
  inputError: {
    borderColor: colors.dark.error,
  },
  errorText: {
    color: colors.dark.error,
    fontSize: 12,
    marginTop: 4,
  },
});