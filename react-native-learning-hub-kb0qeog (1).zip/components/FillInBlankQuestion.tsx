import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '@/constants/colors';
import { Button } from './Button';
import { TextInput } from './TextInput';
import { BlankInfo } from '@/types';
import { Check, X } from 'lucide-react-native';

interface FillInBlankQuestionProps {
  code: string;
  blanks: BlankInfo[];
  onSubmit: (isCorrect: boolean) => void;
}

export const FillInBlankQuestion: React.FC<FillInBlankQuestionProps> = ({
  code,
  blanks,
  onSubmit
}) => {
  const [answers, setAnswers] = useState<{ [key: string]: string }>({});
  const [submitted, setSubmitted] = useState(false);
  const [results, setResults] = useState<{ [key: string]: boolean }>({});
  
  useEffect(() => {
    // Initialize answers
    const initialAnswers: { [key: string]: string } = {};
    blanks.forEach(blank => {
      initialAnswers[blank.id] = '';
    });
    setAnswers(initialAnswers);
  }, [blanks]);
  
  const handleAnswerChange = (id: string, text: string) => {
    setAnswers(prev => ({
      ...prev,
      [id]: text
    }));
  };
  
  const handleSubmit = () => {
    const newResults: { [key: string]: boolean } = {};
    let allCorrect = true;
    
    blanks.forEach(blank => {
      const isCorrect = answers[blank.id].trim().toLowerCase() === blank.correctAnswer.toLowerCase();
      newResults[blank.id] = isCorrect;
      if (!isCorrect) allCorrect = false;
    });
    
    setResults(newResults);
    setSubmitted(true);
    onSubmit(allCorrect);
  };
  
  // Replace placeholders in code with input fields
  const renderCodeWithBlanks = () => {
    let renderedCode = code;
    
    blanks.forEach((blank, index) => {
      const placeholder = `___${blank.id}___`;
      const inputField = (
        <View key={blank.id} style={styles.inputContainer}>
          <TextInput
            value={answers[blank.id] || ''}
            onChangeText={(text) => handleAnswerChange(blank.id, text)}
            placeholder="Fill in..."
            style={[
              styles.blankInput,
              submitted && (
                results[blank.id] 
                  ? styles.correctInput 
                  : styles.incorrectInput
              )
            ]}
            editable={!submitted}
          />
          {submitted && (
            <View style={styles.resultIcon}>
              {results[blank.id] ? (
                <Check size={16} color={colors.dark.success} />
              ) : (
                <X size={16} color={colors.dark.error} />
              )}
            </View>
          )}
        </View>
      );
      
      // Replace the placeholder with the input field
      renderedCode = renderedCode.replace(placeholder, `[BLANK_${index}]`);
    });
    
    // Split by the [BLANK_n] markers
    const parts = renderedCode.split(/\[BLANK_\d+\]/);
    
    return (
      <View style={styles.codeContainer}>
        {parts.map((part, index) => (
          <React.Fragment key={`part-${index}`}>
            <Text style={styles.codeText}>{part}</Text>
            {index < blanks.length && (
              <View key={`blank-${index}`} style={styles.inputContainer}>
                <TextInput
                  value={answers[blanks[index].id] || ''}
                  onChangeText={(text) => handleAnswerChange(blanks[index].id, text)}
                  placeholder="Fill in..."
                  style={[
                    styles.blankInput,
                    submitted && (
                      results[blanks[index].id] 
                        ? styles.correctInput 
                        : styles.incorrectInput
                    )
                  ]}
                  editable={!submitted}
                />
                {submitted && (
                  <View style={styles.resultIcon}>
                    {results[blanks[index].id] ? (
                      <Check size={16} color={colors.dark.success} />
                    ) : (
                      <X size={16} color={colors.dark.error} />
                    )}
                  </View>
                )}
              </View>
            )}
          </React.Fragment>
        ))}
      </View>
    );
  };
  
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.instructions}>Fill in the blanks to complete the code:</Text>
      
      {renderCodeWithBlanks()}
      
      {submitted && (
        <View style={styles.correctAnswersContainer}>
          <Text style={styles.correctAnswersTitle}>Correct Answers:</Text>
          {blanks.map(blank => (
            <View key={`answer-${blank.id}`} style={styles.answerRow}>
              <Text style={styles.blankId}>Blank {blank.id}:</Text>
              <Text style={styles.correctAnswer}>{blank.correctAnswer}</Text>
            </View>
          ))}
        </View>
      )}
      
      {!submitted && (
        <Button
          title="Submit"
          onPress={handleSubmit}
          style={styles.submitButton}
          disabled={Object.values(answers).some(answer => !answer.trim())}
        />
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  instructions: {
    fontSize: 16,
    color: colors.dark.text,
    marginBottom: 16,
  },
  codeContainer: {
    backgroundColor: '#1E1E2E',
    borderRadius: 8,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  codeText: {
    fontFamily: 'monospace',
    fontSize: 14,
    color: '#E4E4E7',
    lineHeight: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },
  blankInput: {
    flex: 1,
    backgroundColor: `${colors.dark.primary}20`,
    borderWidth: 1,
    borderColor: colors.dark.primary,
    borderRadius: 4,
    padding: 8,
    color: colors.dark.text,
    fontFamily: 'monospace',
    fontSize: 14,
    height: 40,
  },
  correctInput: {
    borderColor: colors.dark.success,
    backgroundColor: `${colors.dark.success}20`,
  },
  incorrectInput: {
    borderColor: colors.dark.error,
    backgroundColor: `${colors.dark.error}20`,
  },
  resultIcon: {
    marginLeft: 8,
  },
  submitButton: {
    marginTop: 16,
  },
  correctAnswersContainer: {
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    padding: 16,
    marginTop: 16,
    marginBottom: 24,
  },
  correctAnswersTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
  },
  answerRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  blankId: {
    width: 80,
    fontSize: 14,
    color: colors.dark.subtext,
  },
  correctAnswer: {
    flex: 1,
    fontSize: 14,
    color: colors.dark.success,
    fontFamily: 'monospace',
  },
});