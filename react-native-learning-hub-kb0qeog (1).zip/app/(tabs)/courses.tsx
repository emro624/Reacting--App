import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { router } from 'expo-router';
import { Card } from '@/components/Card';
import { SearchBar } from '@/components/SearchBar';
import { colors } from '@/constants/colors';
import { courses } from '@/data/courses';
import { useProgressStore } from '@/store/progress-store';

export default function CoursesScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const { progress } = useProgressStore();
  
  const filteredCourses = courses.filter(course => 
    course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.level.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const getCourseProgress = (courseId: string) => {
    if (progress[courseId]) {
      return progress[courseId].progress;
    }
    return 0;
  };
  
  const renderCourseItem = ({ item }: { item: typeof courses[0] }) => {
    const courseProgress = getCourseProgress(item.id);
    
    return (
      <Card
        title={item.title}
        subtitle={`${item.duration} • ${item.level}${courseProgress > 0 ? ` • ${courseProgress}% complete` : ''}`}
        image={item.image}
        onPress={() => router.push(`/course/${item.id}`)}
        style={styles.courseCard}
      >
        <Text style={styles.description} numberOfLines={2}>
          {item.description}
        </Text>
        <View style={styles.lessonCount}>
          <Text style={styles.lessonCountText}>
            {item.lessons.length} {item.lessons.length === 1 ? 'lesson' : 'lessons'}
          </Text>
        </View>
      </Card>
    );
  };
  
  return (
    <View style={styles.container}>
      <SearchBar
        value={searchQuery}
        onChangeText={setSearchQuery}
        placeholder="Search courses..."
      />
      
      {filteredCourses.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No courses found</Text>
        </View>
      ) : (
        <FlatList
          data={filteredCourses}
          renderItem={renderCourseItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
    padding: 16,
  },
  listContent: {
    paddingBottom: 16,
  },
  courseCard: {
    marginBottom: 16,
  },
  description: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginTop: 8,
    marginBottom: 12,
  },
  lessonCount: {
    alignSelf: 'flex-start',
    backgroundColor: `${colors.dark.primary}20`,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  lessonCountText: {
    fontSize: 12,
    color: colors.dark.primary,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: colors.dark.subtext,
  },
});