import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Image } from 'expo-image';
import { useAuthStore } from '@/store/auth-store';
import { useProgressStore } from '@/store/progress-store';
import { colors } from '@/constants/colors';
import { ProgressBar } from '@/components/ProgressBar';
import { courses } from '@/data/courses';
import { LogOut, Award, BookOpen, Settings, Moon } from 'lucide-react-native';
import { router } from 'expo-router';

export default function ProfileScreen() {
  const { user, logout } = useAuthStore();
  const { progress, getOverallProgress } = useProgressStore();
  
  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Logout',
          onPress: () => {
            logout();
            router.replace('/(auth)');
          },
          style: 'destructive',
        },
      ]
    );
  };
  
  const getCompletedCoursesCount = () => {
    return Object.keys(progress).filter(courseId => progress[courseId].completed).length;
  };
  
  const getInProgressCoursesCount = () => {
    return Object.keys(progress).filter(courseId => 
      !progress[courseId].completed && progress[courseId].progress > 0
    ).length;
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <View style={styles.profileImageContainer}>
          <Text style={styles.profileInitial}>{user?.name.charAt(0).toUpperCase()}</Text>
        </View>
        <Text style={styles.name}>{user?.name}</Text>
        <Text style={styles.email}>{user?.email}</Text>
        <Text style={styles.joinDate}>
          Joined {new Date(user?.joinedAt || '').toLocaleDateString()}
        </Text>
      </View>
      
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <View style={[styles.statIconContainer, { backgroundColor: `${colors.dark.primary}20` }]}>
            <BookOpen size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.statValue}>{getInProgressCoursesCount()}</Text>
          <Text style={styles.statLabel}>In Progress</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={[styles.statIconContainer, { backgroundColor: `${colors.dark.success}20` }]}>
            <Award size={20} color={colors.dark.success} />
          </View>
          <Text style={styles.statValue}>{getCompletedCoursesCount()}</Text>
          <Text style={styles.statLabel}>Completed</Text>
        </View>
      </View>
      
      <View style={styles.progressSection}>
        <Text style={styles.sectionTitle}>Overall Progress</Text>
        <ProgressBar 
          progress={getOverallProgress()} 
          showPercentage 
          style={styles.progressBar}
        />
      </View>
      
      {Object.keys(progress).length > 0 && (
        <View style={styles.coursesSection}>
          <Text style={styles.sectionTitle}>Your Courses</Text>
          
          {Object.keys(progress).map(courseId => {
            const course = courses.find(c => c.id === courseId);
            if (!course) return null;
            
            return (
              <TouchableOpacity 
                key={courseId}
                style={styles.courseItem}
                onPress={() => router.push(`/course/${courseId}`)}
              >
                <Image
                  source={{ uri: course.image }}
                  style={styles.courseImage}
                  contentFit="cover"
                />
                <View style={styles.courseInfo}>
                  <Text style={styles.courseTitle}>{course.title}</Text>
                  <ProgressBar 
                    progress={progress[courseId].progress} 
                    style={styles.courseProgress}
                  />
                  <Text style={styles.courseProgressText}>
                    {progress[courseId].progress}% complete
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      )}
      
      <View style={styles.settingsSection}>
        <Text style={styles.sectionTitle}>Settings</Text>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingIconContainer}>
            <Moon size={20} color={colors.dark.text} />
          </View>
          <Text style={styles.settingText}>Dark Mode</Text>
          <View style={styles.toggle}>
            <View style={styles.toggleOn} />
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingIconContainer}>
            <Settings size={20} color={colors.dark.text} />
          </View>
          <Text style={styles.settingText}>App Settings</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.settingItem, styles.logoutItem]}
          onPress={handleLogout}
        >
          <View style={styles.settingIconContainer}>
            <LogOut size={20} color={colors.dark.error} />
          </View>
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  profileImageContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileInitial: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginBottom: 4,
  },
  joinDate: {
    fontSize: 12,
    color: colors.dark.subtext,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  statIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.dark.subtext,
  },
  progressSection: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  progressBar: {
    marginBottom: 8,
  },
  coursesSection: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  courseItem: {
    flexDirection: 'row',
    marginBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
    paddingBottom: 16,
  },
  courseImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  courseInfo: {
    flex: 1,
  },
  courseTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.dark.text,
    marginBottom: 8,
  },
  courseProgress: {
    marginBottom: 4,
  },
  courseProgressText: {
    fontSize: 12,
    color: colors.dark.subtext,
  },
  settingsSection: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  settingIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: `${colors.dark.primary}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingText: {
    flex: 1,
    fontSize: 16,
    color: colors.dark.text,
  },
  toggle: {
    width: 40,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.dark.primary,
    padding: 2,
    justifyContent: 'center',
  },
  toggleOn: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.dark.text,
    alignSelf: 'flex-end',
  },
  logoutItem: {
    borderBottomWidth: 0,
    marginTop: 8,
  },
  logoutText: {
    flex: 1,
    fontSize: 16,
    color: colors.dark.error,
  },
});