import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { useAuthStore } from '@/store/auth-store';
import { useProgressStore } from '@/store/progress-store';
import { Card } from '@/components/Card';
import { ProgressBar } from '@/components/ProgressBar';
import { colors } from '@/constants/colors';
import { courses } from '@/data/courses';
import { dailyChallenges } from '@/data/daily-challenges';
import { motivationalQuotes } from '@/data/motivational-quotes';
import { ArrowRight, Trophy, Zap } from 'lucide-react-native';

export default function HomeScreen() {
  const { user } = useAuthStore();
  const { progress, getOverallProgress } = useProgressStore();
  const [quote, setQuote] = useState('');
  
  useEffect(() => {
    // Get random motivational quote
    const randomIndex = Math.floor(Math.random() * motivationalQuotes.length);
    setQuote(motivationalQuotes[randomIndex]);
  }, []);
  
  const getRecommendedCourses = () => {
    // Logic to recommend courses based on progress
    const completedCourseIds = Object.keys(progress).filter(
      courseId => progress[courseId].completed
    );
    
    return courses.filter(course => !completedCourseIds.includes(course.id)).slice(0, 2);
  };
  
  const getDailyChallenge = () => {
    // Get a random challenge
    const randomIndex = Math.floor(Math.random() * dailyChallenges.length);
    return dailyChallenges[randomIndex];
  };
  
  const recommendedCourses = getRecommendedCourses();
  const dailyChallenge = getDailyChallenge();
  const overallProgress = getOverallProgress();
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Welcome Section */}
      <View style={styles.welcomeSection}>
        <Text style={styles.welcomeText}>Welcome back,</Text>
        <Text style={styles.nameText}>{user?.name}</Text>
      </View>
      
      {/* Progress Overview */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Your Progress</Text>
        <ProgressBar 
          progress={overallProgress} 
          showPercentage 
          style={styles.progressBar}
        />
        <Text style={styles.progressText}>
          {overallProgress === 0 
            ? "Let's start learning!" 
            : `You're making great progress!`}
        </Text>
      </View>
      
      {/* Daily Challenge */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Daily Challenge</Text>
      </View>
      
      <TouchableOpacity 
        style={styles.challengeCard}
        onPress={() => router.push('/practice')}
        activeOpacity={0.9}
      >
        <View style={styles.challengeIconContainer}>
          <Zap size={24} color={colors.dark.warning} />
        </View>
        <View style={styles.challengeContent}>
          <Text style={styles.challengeTitle}>{dailyChallenge.title}</Text>
          <Text style={styles.challengeDescription}>{dailyChallenge.description}</Text>
          <View style={styles.challengeDifficulty}>
            <Text style={styles.difficultyText}>{dailyChallenge.difficulty}</Text>
          </View>
        </View>
      </TouchableOpacity>
      
      {/* Continue Learning */}
      {Object.keys(progress).length > 0 && (
        <>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Continue Learning</Text>
            <TouchableOpacity onPress={() => router.push('/courses')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          {Object.keys(progress)
            .filter(courseId => !progress[courseId].completed)
            .slice(0, 1)
            .map(courseId => {
              const course = courses.find(c => c.id === courseId);
              if (!course) return null;
              
              return (
                <Card
                  key={course.id}
                  title={course.title}
                  subtitle={`${progress[courseId].progress}% complete`}
                  image={course.image}
                  onPress={() => router.push(`/course/${course.id}`)}
                  style={styles.courseCard}
                >
                  <ProgressBar 
                    progress={progress[courseId].progress} 
                    style={styles.courseProgress}
                  />
                  <View style={styles.continueButton}>
                    <Text style={styles.continueText}>Continue</Text>
                    <ArrowRight size={16} color={colors.dark.text} />
                  </View>
                </Card>
              );
            })}
        </>
      )}
      
      {/* Recommended Courses */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Recommended for You</Text>
        <TouchableOpacity onPress={() => router.push('/courses')}>
          <Text style={styles.seeAllText}>See All</Text>
        </TouchableOpacity>
      </View>
      
      {recommendedCourses.map(course => (
        <Card
          key={course.id}
          title={course.title}
          subtitle={`${course.duration} • ${course.level}`}
          image={course.image}
          onPress={() => router.push(`/course/${course.id}`)}
          style={styles.courseCard}
        />
      ))}
      
      {/* Motivational Quote */}
      <View style={styles.quoteCard}>
        <Text style={styles.quoteText}>"{quote}"</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  welcomeSection: {
    marginBottom: 24,
  },
  welcomeText: {
    fontSize: 16,
    color: colors.dark.subtext,
  },
  nameText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  card: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  progressBar: {
    marginBottom: 12,
  },
  progressText: {
    fontSize: 14,
    color: colors.dark.subtext,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  seeAllText: {
    fontSize: 14,
    color: colors.dark.primary,
  },
  challengeCard: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    flexDirection: 'row',
    alignItems: 'center',
  },
  challengeIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: `${colors.dark.warning}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  challengeContent: {
    flex: 1,
  },
  challengeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  challengeDescription: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginBottom: 8,
  },
  challengeDifficulty: {
    alignSelf: 'flex-start',
    backgroundColor: `${colors.dark.warning}20`,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  difficultyText: {
    fontSize: 12,
    color: colors.dark.warning,
    textTransform: 'capitalize',
  },
  courseCard: {
    marginBottom: 16,
  },
  courseProgress: {
    marginTop: 8,
    marginBottom: 12,
  },
  continueButton: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-end',
    backgroundColor: colors.dark.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginTop: 8,
  },
  continueText: {
    color: colors.dark.text,
    fontSize: 14,
    fontWeight: '500',
    marginRight: 4,
  },
  quoteCard: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 20,
    marginTop: 16,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: colors.dark.primary,
  },
  quoteText: {
    fontSize: 16,
    fontStyle: 'italic',
    color: colors.dark.text,
    lineHeight: 24,
  },
});