import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { colors } from '@/constants/colors';
import { courses } from '@/data/courses';
import { dailyChallenges } from '@/data/daily-challenges';
import { Question } from '@/types';
import { QuizQuestion } from '@/components/QuizQuestion';
import { Zap, CheckCircle, XCircle } from 'lucide-react-native';

// Collect all questions from all courses
const getAllQuestions = (): Question[] => {
  const questions: Question[] = [];
  
  courses.forEach(course => {
    course.lessons.forEach(lesson => {
      lesson.quiz.questions.forEach(question => {
        questions.push(question);
      });
    });
  });
  
  return questions;
};

export default function PracticeScreen() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [practiceMode, setPracticeMode] = useState<'daily' | 'random' | 'fill-in-blank'>('daily');
  
  useEffect(() => {
    const allQuestions = getAllQuestions();
    
    if (practiceMode === 'fill-in-blank') {
      // Filter only fill-in-blank questions
      const fillInBlankQuestions = allQuestions.filter(q => q.type === 'fill-in-blank');
      setQuestions(fillInBlankQuestions);
    } else {
      // Shuffle questions
      const shuffledQuestions = [...allQuestions].sort(() => Math.random() - 0.5);
      
      // Take 5 random questions for practice
      setQuestions(shuffledQuestions.slice(0, 5));
    }
  }, [practiceMode]);
  
  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(score + 1);
    }
    
    // Move to next question after a delay
    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        setShowResults(true);
      }
    }, 1500);
  };
  
  const restartPractice = () => {
    setCurrentQuestionIndex(0);
    setScore(0);
    setShowResults(false);
    
    // Reshuffle questions
    const allQuestions = getAllQuestions();
    
    if (practiceMode === 'fill-in-blank') {
      // Filter only fill-in-blank questions
      const fillInBlankQuestions = allQuestions.filter(q => q.type === 'fill-in-blank');
      setQuestions(fillInBlankQuestions);
    } else {
      // Shuffle questions
      const shuffledQuestions = [...allQuestions].sort(() => Math.random() - 0.5);
      setQuestions(shuffledQuestions.slice(0, 5));
    }
  };
  
  const renderDailyChallenge = () => (
    <View style={styles.challengesContainer}>
      <Text style={styles.sectionTitle}>Daily Challenges</Text>
      <FlatList
        data={dailyChallenges}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.challengeCard}
            onPress={() => {
              setPracticeMode('daily');
              restartPractice();
            }}
          >
            <View style={styles.challengeIconContainer}>
              <Zap size={20} color={colors.dark.warning} />
            </View>
            <View style={styles.challengeContent}>
              <Text style={styles.challengeTitle}>{item.title}</Text>
              <Text style={styles.challengeDescription}>{item.description}</Text>
              <View style={styles.challengeDifficulty}>
                <Text style={styles.difficultyText}>{item.difficulty}</Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
      
      <TouchableOpacity 
        style={styles.practiceButton}
        onPress={() => {
          setPracticeMode('random');
          restartPractice();
        }}
      >
        <Text style={styles.practiceButtonText}>Start Random Practice</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={[styles.practiceButton, styles.fillInBlankButton]}
        onPress={() => {
          setPracticeMode('fill-in-blank');
          restartPractice();
        }}
      >
        <Text style={styles.practiceButtonText}>Fill-in-the-Blank Exercises</Text>
      </TouchableOpacity>
    </View>
  );
  
  const renderPracticeQuestions = () => (
    <View style={styles.questionsContainer}>
      {!showResults ? (
        <>
          <View style={styles.progressHeader}>
            <Text style={styles.progressText}>
              Question {currentQuestionIndex + 1} of {questions.length}
            </Text>
            <Text style={styles.scoreText}>Score: {score}</Text>
          </View>
          
          {questions.length > 0 && (
            <QuizQuestion
              question={questions[currentQuestionIndex]}
              onAnswer={handleAnswer}
            />
          )}
        </>
      ) : (
        <View style={styles.resultsContainer}>
          <View style={styles.scoreCircle}>
            <Text style={styles.finalScoreText}>{score}/{questions.length}</Text>
          </View>
          
          <Text style={styles.resultTitle}>
            {score === questions.length 
              ? 'Perfect Score!' 
              : score >= questions.length / 2 
                ? 'Good Job!' 
                : 'Keep Practicing!'}
          </Text>
          
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <CheckCircle size={24} color={colors.dark.success} />
              <Text style={styles.statText}>Correct: {score}</Text>
            </View>
            <View style={styles.statItem}>
              <XCircle size={24} color={colors.dark.error} />
              <Text style={styles.statText}>Incorrect: {questions.length - score}</Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.restartButton}
            onPress={restartPractice}
          >
            <Text style={styles.restartButtonText}>Practice Again</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => {
              setShowResults(false);
              setCurrentQuestionIndex(0);
              setScore(0);
              setPracticeMode('daily');
            }}
          >
            <Text style={styles.backButtonText}>Back to Challenges</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
  
  return (
    <View style={styles.container}>
      {practiceMode === 'daily' && !showResults && currentQuestionIndex === 0
        ? renderDailyChallenge()
        : renderPracticeQuestions()
      }
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  challengesContainer: {
    flex: 1,
    padding: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  challengeCard: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  challengeIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: `${colors.dark.warning}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  challengeContent: {
    flex: 1,
  },
  challengeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  challengeDescription: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginBottom: 8,
  },
  challengeDifficulty: {
    alignSelf: 'flex-start',
    backgroundColor: `${colors.dark.warning}20`,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  difficultyText: {
    fontSize: 12,
    color: colors.dark.warning,
    textTransform: 'capitalize',
  },
  practiceButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  fillInBlankButton: {
    backgroundColor: colors.dark.secondary,
    marginTop: 12,
  },
  practiceButtonText: {
    color: colors.dark.text,
    fontSize: 16,
    fontWeight: '600',
  },
  questionsContainer: {
    flex: 1,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  progressText: {
    fontSize: 14,
    color: colors.dark.subtext,
  },
  scoreText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.primary,
  },
  resultsContainer: {
    flex: 1,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scoreCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: `${colors.dark.primary}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  finalScoreText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.dark.primary,
  },
  resultTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 24,
  },
  statsContainer: {
    width: '100%',
    marginBottom: 32,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.card,
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
  },
  statText: {
    fontSize: 16,
    color: colors.dark.text,
    marginLeft: 12,
  },
  restartButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 16,
    width: '100%',
    alignItems: 'center',
    marginBottom: 12,
  },
  restartButtonText: {
    color: colors.dark.text,
    fontSize: 16,
    fontWeight: '600',
  },
  backButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.dark.border,
    borderRadius: 8,
    padding: 16,
    width: '100%',
    alignItems: 'center',
  },
  backButtonText: {
    color: colors.dark.text,
    fontSize: 16,
  },
});