import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { colors } from '@/constants/colors';
import { resources } from '@/data/resources';
import { ResourceCard } from '@/components/ResourceCard';
import { SearchBar } from '@/components/SearchBar';

export default function ResourcesScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredResources, setFilteredResources] = useState(resources);
  
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredResources(resources);
      return;
    }
    
    const query = searchQuery.toLowerCase();
    const filtered = resources.filter(resource => 
      resource.title.toLowerCase().includes(query) ||
      resource.description.toLowerCase().includes(query) ||
      resource.platform.toLowerCase().includes(query) ||
      resource.tags.some(tag => tag.toLowerCase().includes(query))
    );
    
    setFilteredResources(filtered);
  }, [searchQuery]);
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Learning Resources</Text>
        <Text style={styles.subtitle}>
          Find tutorials, courses, and documentation to enhance your React Native skills
        </Text>
      </View>
      
      <SearchBar
        value={searchQuery}
        onChangeText={setSearchQuery}
        placeholder="Search by topic, platform, or keyword..."
      />
      
      {filteredResources.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No resources found</Text>
          <Text style={styles.emptySubtext}>Try a different search term</Text>
        </View>
      ) : (
        <FlatList
          data={filteredResources}
          renderItem={({ item }) => <ResourceCard resource={item} />}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginBottom: 8,
  },
  listContent: {
    paddingBottom: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: colors.dark.subtext,
  },
});