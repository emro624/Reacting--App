import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { colors } from '@/constants/colors';
import { courses } from '@/data/courses';
import { CodeBlock } from '@/components/CodeBlock';
import { useProgressStore } from '@/store/progress-store';
import { ArrowRight } from 'lucide-react-native';

export default function LessonScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [lesson, setLesson] = useState<typeof courses[0]['lessons'][0] | null>(null);
  const [courseId, setCourseId] = useState<string>('');
  const [lessonIndex, setLessonIndex] = useState<number>(0);
  const { updateLessonProgress } = useProgressStore();
  
  useEffect(() => {
    // Find the lesson and its course
    for (const course of courses) {
      const index = course.lessons.findIndex(l => l.id === id);
      if (index !== -1) {
        setLesson(course.lessons[index]);
        setCourseId(course.id);
        setLessonIndex(index);
        
        // Update progress
        const progressPercentage = Math.round(((index + 0.5) / course.lessons.length) * 100);
        updateLessonProgress(course.id, progressPercentage);
        break;
      }
    }
  }, [id]);
  
  if (!lesson) {
    return (
      <View style={styles.notFoundContainer}>
        <Text style={styles.notFoundText}>Lesson not found</Text>
      </View>
    );
  }
  
  const handleStartQuiz = () => {
    router.push(`/quiz/${lesson.id}`);
  };
  
  const renderMarkdownContent = (content: string) => {
    // This is a very simple markdown parser
    // In a real app, you would use a proper markdown library
    
    const lines = content.trim().split('\n');
    
    return lines.map((line, index) => {
      if (line.startsWith('# ')) {
        return (
          <Text key={index} style={styles.heading1}>
            {line.substring(2)}
          </Text>
        );
      } else if (line.startsWith('## ')) {
        return (
          <Text key={index} style={styles.heading2}>
            {line.substring(3)}
          </Text>
        );
      } else if (line.startsWith('- ')) {
        return (
          <Text key={index} style={styles.listItem}>
            • {line.substring(2)}
          </Text>
        );
      } else if (line.trim() === '') {
        return <View key={index} style={styles.spacer} />;
      } else {
        return (
          <Text key={index} style={styles.paragraph}>
            {line}
          </Text>
        );
      }
    });
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Stack.Screen 
        options={{ 
          title: lesson.title,
          headerBackTitle: "Course"
        }} 
      />
      
      <View style={styles.lessonContent}>
        {renderMarkdownContent(lesson.content)}
        
        <Text style={styles.codeTitle}>Example Code:</Text>
        <CodeBlock code={lesson.codeExample} />
      </View>
      
      <TouchableOpacity 
        style={styles.quizButton}
        onPress={handleStartQuiz}
      >
        <Text style={styles.quizButtonText}>Take Quiz</Text>
        <ArrowRight size={18} color={colors.dark.text} />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notFoundText: {
    fontSize: 18,
    color: colors.dark.text,
  },
  lessonContent: {
    marginBottom: 24,
  },
  heading1: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
    marginTop: 8,
  },
  heading2: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
    marginTop: 8,
  },
  paragraph: {
    fontSize: 16,
    color: colors.dark.text,
    lineHeight: 24,
    marginBottom: 12,
  },
  listItem: {
    fontSize: 16,
    color: colors.dark.text,
    lineHeight: 24,
    marginBottom: 8,
    paddingLeft: 8,
  },
  spacer: {
    height: 12,
  },
  codeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
    marginTop: 8,
  },
  quizButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  quizButtonText: {
    color: colors.dark.text,
    fontSize: 16,
    fontWeight: '600',
    marginRight: 8,
  },
});