import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { colors } from '@/constants/colors';
import { courses } from '@/data/courses';
import { QuizQuestion } from '@/components/QuizQuestion';
import { useProgressStore } from '@/store/progress-store';
import { CheckCircle, ArrowRight } from 'lucide-react-native';

export default function QuizScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [lesson, setLesson] = useState<typeof courses[0]['lessons'][0] | null>(null);
  const [courseId, setCourseId] = useState<string>('');
  const [lessonIndex, setLessonIndex] = useState<number>(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  
  const { updateQuizScore, markCourseCompleted } = useProgressStore();
  
  useEffect(() => {
    // Find the lesson and its course
    for (const course of courses) {
      const index = course.lessons.findIndex(l => l.id === id);
      if (index !== -1) {
        setLesson(course.lessons[index]);
        setCourseId(course.id);
        setLessonIndex(index);
        break;
      }
    }
  }, [id]);
  
  if (!lesson) {
    return (
      <View style={styles.notFoundContainer}>
        <Text style={styles.notFoundText}>Quiz not found</Text>
      </View>
    );
  }
  
  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(score + 1);
    }
    
    // Move to next question after a delay
    setTimeout(() => {
      if (currentQuestionIndex < lesson.quiz.questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        setShowResults(true);
        
        // Calculate score percentage
        const scorePercentage = Math.round((score / lesson.quiz.questions.length) * 100);
        
        // Update quiz score
        updateQuizScore(courseId, lesson.quiz.id, scorePercentage);
        
        // If this is the last lesson in the course, mark the course as completed
        const course = courses.find(c => c.id === courseId);
        if (course && lessonIndex === course.lessons.length - 1) {
          markCourseCompleted(courseId);
        }
      }
    }, 1500);
  };
  
  const handleContinue = () => {
    const course = courses.find(c => c.id === courseId);
    if (!course) return;
    
    // If this is the last lesson in the course
    if (lessonIndex === course.lessons.length - 1) {
      router.push(`/course/${courseId}`);
    } else {
      // Go to the next lesson
      router.push(`/lesson/${course.lessons[lessonIndex + 1].id}`);
    }
  };
  
  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: `Quiz: ${lesson.title}`,
          headerBackTitle: "Lesson"
        }} 
      />
      
      {!showResults ? (
        <>
          <View style={styles.progressHeader}>
            <Text style={styles.progressText}>
              Question {currentQuestionIndex + 1} of {lesson.quiz.questions.length}
            </Text>
            <Text style={styles.scoreText}>Score: {score}</Text>
          </View>
          
          <QuizQuestion
            question={lesson.quiz.questions[currentQuestionIndex]}
            onAnswer={handleAnswer}
          />
        </>
      ) : (
        <View style={styles.resultsContainer}>
          <View style={styles.scoreCircle}>
            <Text style={styles.finalScoreText}>
              {score}/{lesson.quiz.questions.length}
            </Text>
          </View>
          
          <Text style={styles.resultTitle}>
            {score === lesson.quiz.questions.length 
              ? 'Perfect Score!' 
              : score >= lesson.quiz.questions.length / 2 
                ? 'Good Job!' 
                : 'Keep Learning!'}
          </Text>
          
          <Text style={styles.resultMessage}>
            {score === lesson.quiz.questions.length 
              ? "You've mastered this lesson!" 
              : score >= lesson.quiz.questions.length / 2 
                ? "You're making great progress!" 
                : "Don't worry, practice makes perfect!"}
          </Text>
          
          <TouchableOpacity 
            style={styles.continueButton}
            onPress={handleContinue}
          >
            <Text style={styles.continueButtonText}>
              {lessonIndex === courses.find(c => c.id === courseId)?.lessons.length! - 1
                ? 'Finish Course'
                : 'Next Lesson'}
            </Text>
            <ArrowRight size={18} color={colors.dark.text} />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notFoundText: {
    fontSize: 18,
    color: colors.dark.text,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  progressText: {
    fontSize: 14,
    color: colors.dark.subtext,
  },
  scoreText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.primary,
  },
  resultsContainer: {
    flex: 1,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scoreCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: `${colors.dark.primary}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  finalScoreText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.dark.primary,
  },
  resultTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
  },
  resultMessage: {
    fontSize: 16,
    color: colors.dark.subtext,
    textAlign: 'center',
    marginBottom: 32,
  },
  continueButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 16,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueButtonText: {
    color: colors.dark.text,
    fontSize: 16,
    fontWeight: '600',
    marginRight: 8,
  },
});