import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Image } from 'expo-image';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { colors } from '@/constants/colors';
import { courses } from '@/data/courses';
import { ProgressBar } from '@/components/ProgressBar';
import { useProgressStore } from '@/store/progress-store';
import { Clock, BookOpen, BarChart2, ArrowRight, CheckCircle } from 'lucide-react-native';

export default function CourseDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { progress, updateLessonProgress } = useProgressStore();
  
  const course = courses.find(c => c.id === id);
  
  if (!course) {
    return (
      <View style={styles.notFoundContainer}>
        <Text style={styles.notFoundText}>Course not found</Text>
      </View>
    );
  }
  
  const courseProgress = progress[id] || {
    completed: false,
    progress: 0,
    lastAccessed: new Date().toISOString(),
    quizScores: {},
  };
  
  const handleStartCourse = () => {
    if (courseProgress.progress === 0) {
      updateLessonProgress(id, 5); // Mark as started
    }
    
    router.push(`/lesson/${course.lessons[0].id}`);
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Stack.Screen 
        options={{ 
          title: course.title,
          headerBackTitle: "Courses"
        }} 
      />
      
      <Image
        source={{ uri: course.image }}
        style={styles.coverImage}
        contentFit="cover"
      />
      
      <View style={styles.header}>
        <Text style={styles.title}>{course.title}</Text>
        <Text style={styles.description}>{course.description}</Text>
        
        <View style={styles.metaContainer}>
          <View style={styles.metaItem}>
            <Clock size={16} color={colors.dark.subtext} />
            <Text style={styles.metaText}>{course.duration}</Text>
          </View>
          
          <View style={styles.metaItem}>
            <BookOpen size={16} color={colors.dark.subtext} />
            <Text style={styles.metaText}>
              {course.lessons.length} {course.lessons.length === 1 ? 'lesson' : 'lessons'}
            </Text>
          </View>
          
          <View style={styles.metaItem}>
            <BarChart2 size={16} color={colors.dark.subtext} />
            <Text style={styles.metaText}>{course.level}</Text>
          </View>
        </View>
        
        {courseProgress.progress > 0 && (
          <View style={styles.progressContainer}>
            <Text style={styles.progressLabel}>Your Progress</Text>
            <ProgressBar 
              progress={courseProgress.progress} 
              showPercentage 
              style={styles.progressBar}
            />
          </View>
        )}
        
        <TouchableOpacity 
          style={styles.startButton}
          onPress={handleStartCourse}
        >
          <Text style={styles.startButtonText}>
            {courseProgress.progress === 0 
              ? 'Start Course' 
              : courseProgress.completed 
                ? 'Review Course' 
                : 'Continue Learning'}
          </Text>
          <ArrowRight size={18} color={colors.dark.text} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.lessonsContainer}>
        <Text style={styles.sectionTitle}>Course Content</Text>
        
        {course.lessons.map((lesson, index) => {
          const isCompleted = courseProgress.progress >= ((index + 1) / course.lessons.length) * 100;
          
          return (
            <TouchableOpacity 
              key={lesson.id}
              style={[
                styles.lessonItem,
                index === course.lessons.length - 1 && styles.lastLessonItem
              ]}
              onPress={() => router.push(`/lesson/${lesson.id}`)}
            >
              <View style={styles.lessonNumber}>
                <Text style={styles.lessonNumberText}>{index + 1}</Text>
              </View>
              <View style={styles.lessonContent}>
                <Text style={styles.lessonTitle}>{lesson.title}</Text>
                <Text style={styles.lessonQuizInfo}>
                  Includes {lesson.quiz.questions.length} practice questions
                </Text>
              </View>
              {isCompleted ? (
                <CheckCircle size={20} color={colors.dark.success} />
              ) : (
                <ArrowRight size={20} color={colors.dark.subtext} />
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    paddingBottom: 32,
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notFoundText: {
    fontSize: 18,
    color: colors.dark.text,
  },
  coverImage: {
    width: '100%',
    height: 200,
  },
  header: {
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: colors.dark.subtext,
    marginBottom: 16,
    lineHeight: 24,
  },
  metaContainer: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  metaText: {
    fontSize: 14,
    color: colors.dark.subtext,
    marginLeft: 4,
    textTransform: 'capitalize',
  },
  progressContainer: {
    marginBottom: 24,
  },
  progressLabel: {
    fontSize: 14,
    color: colors.dark.text,
    marginBottom: 8,
  },
  progressBar: {
    marginBottom: 4,
  },
  startButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  startButtonText: {
    color: colors.dark.text,
    fontSize: 16,
    fontWeight: '600',
    marginRight: 8,
  },
  lessonsContainer: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  lessonItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
  },
  lastLessonItem: {
    marginBottom: 0,
  },
  lessonNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: `${colors.dark.primary}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  lessonNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.dark.primary,
  },
  lessonContent: {
    flex: 1,
  },
  lessonTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.dark.text,
    marginBottom: 4,
  },
  lessonQuizInfo: {
    fontSize: 12,
    color: colors.dark.subtext,
  },
});