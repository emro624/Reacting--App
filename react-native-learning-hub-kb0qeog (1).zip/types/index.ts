export interface User {
  id: string;
  name: string;
  email: string;
  progress: CourseProgress;
  joinedAt: string;
}

export interface CourseProgress {
  [courseId: string]: {
    completed: boolean;
    progress: number; // 0-100
    lastAccessed: string;
    quizScores: {
      [quizId: string]: number; // 0-100
    };
  };
}

export interface Course {
  id: string;
  title: string;
  description: string;
  image: string;
  duration: string;
  lessons: Lesson[];
  level: 'beginner' | 'intermediate' | 'advanced';
}

export interface Lesson {
  id: string;
  title: string;
  content: string;
  codeExample: string;
  quiz: Quiz;
}

export interface Quiz {
  id: string;
  questions: Question[];
}

export interface Question {
  id: string;
  type: 'multiple-choice' | 'true-false' | 'code-completion' | 'error-detection' | 'fill-in-blank';
  question: string;
  options?: string[];
  correctAnswer: string | string[];
  explanation: string;
  code?: string;
  blanks?: BlankInfo[];
}

export interface BlankInfo {
  id: string;
  correctAnswer: string;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  url: string;
  platform: 'youtube' | 'udemy' | 'btk' | 'other';
  tags: string[];
  image: string;
}

export interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  completed: boolean;
}