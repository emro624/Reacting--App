// App color scheme
export const colors = {
  dark: {
    background: '#121214',
    card: '#1E1E24',
    text: '#FFFFFF',
    subtext: '#A0A0A0',
    primary: '#8A5CF6', // Purple
    secondary: '#4ADE80', // Green
    border: '#2A2A30',
    error: '#FF5252',
    success: '#4ADE80',
    warning: '#FFD600',
    inactive: '#4A4A55',
  }
};