import { DailyChallenge } from '@/types';

export const dailyChallenges: DailyChallenge[] = [
  {
    id: '1',
    title: 'Create a Counter Component',
    description: 'Build a simple counter component with increment and decrement buttons using useState',
    difficulty: 'easy',
    completed: false
  },
  {
    id: '2',
    title: 'Implement Dark Mode Toggle',
    description: 'Create a toggle switch that changes the app theme between light and dark mode',
    difficulty: 'medium',
    completed: false
  },
  {
    id: '3',
    title: 'Build a Todo List',
    description: 'Create a todo list app with add, delete, and mark as complete functionality',
    difficulty: 'medium',
    completed: false
  },
  {
    id: '4',
    title: 'Fill in the Blanks Challenge',
    description: 'Complete React Native code snippets by filling in the missing parts',
    difficulty: 'easy',
    completed: false
  },
  {
    id: '5',
    title: 'Create an Animated Card',
    description: 'Build a card component with flip animation using the Animated API',
    difficulty: 'hard',
    completed: false
  }
];