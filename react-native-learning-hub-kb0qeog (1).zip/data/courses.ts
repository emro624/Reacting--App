import { Course } from '@/types';

export const courses: Course[] = [
  {
    id: '1',
    title: 'React Native Fundamentals',
    description: 'Learn the core concepts of React Native development',
    image: 'https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?q=80&w=2070&auto=format&fit=crop',
    duration: '2 hours',
    level: 'beginner',
    lessons: [
      {
        id: '1-1',
        title: 'Introduction to React Native',
        content: `
# Introduction to React Native

React Native is a popular JavaScript framework that allows you to build mobile applications. It uses the same design as React, letting you compose a rich mobile UI from declarative components.

## Key Features

- **Learn once, write anywhere**: Create mobile apps for both iOS and Android using a single codebase
- **React-based**: If you know React, you can use your existing knowledge
- **Native Components**: Uses the same fundamental UI building blocks as regular iOS and Android apps
- **Hot Reloading**: See your changes instantly without rebuilding your app

React Native combines the best parts of native development with React, a best-in-class JavaScript library for building user interfaces.
        `,
        codeExample: `
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function HelloWorld() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Hello, React Native!</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  text: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
});
        `,
        quiz: {
          id: '1-1-quiz',
          questions: [
            {
              id: '1-1-q1',
              type: 'multiple-choice',
              question: 'What is React Native?',
              options: [
                'A JavaScript framework for building mobile apps',
                'A programming language for iOS development',
                'A database management system',
                'A design tool for creating UI mockups'
              ],
              correctAnswer: 'A JavaScript framework for building mobile apps',
              explanation: 'React Native is a JavaScript framework that allows developers to build mobile applications for iOS and Android using a single codebase.'
            },
            {
              id: '1-1-q2',
              type: 'true-false',
              question: 'React Native apps need to be compiled differently for iOS and Android.',
              correctAnswer: 'false',
              explanation: 'While React Native does compile to native code, you write your app once in JavaScript and React Native handles the platform-specific implementations.'
            },
            {
              id: '1-1-q3',
              type: 'fill-in-blank',
              question: 'Complete the basic React Native component:',
              code: `
import React from 'react';
import { ___1___, Text } from 'react-native';

export default function MyComponent() {
  return (
    <___1___>
      <Text>Hello from ___2___!</Text>
    </___1___>
  );
}`,
              blanks: [
                { id: '1', correctAnswer: 'View' },
                { id: '2', correctAnswer: 'React Native' }
              ],
              explanation: "The View component is the fundamental building block in React Native, similar to a div in web development. It's a container that supports layout with flexbox and styling."
            }
          ]
        }
      },
      {
        id: '1-2',
        title: 'Components and Props',
        content: `
# Components and Props

Components are the building blocks of any React Native application. A component can be as simple as a button or as complex as an entire screen.

## What are Components?

Components let you split the UI into independent, reusable pieces. Conceptually, components are like JavaScript functions - they accept inputs (called "props") and return React elements describing what should appear on the screen.

## Types of Components

1. **Function Components**: Defined as JavaScript functions
2. **Class Components**: Defined using ES6 classes

## Props

Props (short for "properties") are how you pass data from a parent component to a child component. They are read-only and help make your components reusable.
        `,
        codeExample: `
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

// A simple component that accepts props
function Greeting(props) {
  return (
    <View style={styles.greetingContainer}>
      <Text style={styles.greetingText}>Hello, {props.name}!</Text>
    </View>
  );
}

// Using the component with different props
export default function App() {
  return (
    <View style={styles.container}>
      <Greeting name="Alice" />
      <Greeting name="Bob" />
      <Greeting name="Charlie" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  greetingContainer: {
    margin: 10,
    padding: 10,
    backgroundColor: '#e0e0e0',
    borderRadius: 5,
  },
  greetingText: {
    fontSize: 18,
  },
});
        `,
        quiz: {
          id: '1-2-quiz',
          questions: [
            {
              id: '1-2-q1',
              type: 'multiple-choice',
              question: 'What are props in React Native?',
              options: [
                'Properties that allow you to pass data to components',
                'Functions that render UI elements',
                'Special styling attributes',
                'Native device features'
              ],
              correctAnswer: 'Properties that allow you to pass data to components',
              explanation: 'Props (short for properties) are used to pass data from parent to child components in React Native.'
            },
            {
              id: '1-2-q2',
              type: 'code-completion',
              question: 'Complete the code to create a Button component that accepts a title prop:',
              code: `
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

function Button(____) {
  return (
    <TouchableOpacity style={styles.button}>
      <Text style={styles.buttonText}>{____}</Text>
    </TouchableOpacity>
  );
}
              `,
              correctAnswer: ['props', 'props.title'],
              explanation: 'The component should accept props as its parameter, and then use props.title to display the button text.'
            },
            {
              id: '1-2-q3',
              type: 'fill-in-blank',
              question: 'Complete the code to create a Profile component that accepts and uses props:',
              code: `
import React from 'react';
import { View, Text, Image } from 'react-native';

export default function Profile(___1___) {
  return (
    <View style={{ padding: 20 }}>
      <Image 
        source={{ uri: ___1___.imageUrl }} 
        style={{ width: 100, height: 100, borderRadius: 50 }}
      />
      <Text style={{ fontSize: 24, fontWeight: 'bold' }}>
        {___1___.___2___}
      </Text>
      <Text>{___1___.bio}</Text>
    </View>
  );
}

// Usage:
// <Profile name="John Doe" bio="React Native Developer" imageUrl="https://example.com/profile.jpg" />
`,
              blanks: [
                { id: '1', correctAnswer: 'props' },
                { id: '2', correctAnswer: 'name' }
              ],
              explanation: 'Components receive data through props (short for properties). In this example, the Profile component accepts props including name, bio, and imageUrl, which are then used to render the component.'
            }
          ]
        }
      },
      {
        id: '1-3',
        title: 'State and Hooks',
        content: `
# State and Hooks

State is a way for components to maintain and update data that can change over time. When state changes, the component re-renders.

## What is State?

State is similar to props, but it is private and fully controlled by the component. State is used for data that will change during the component's lifecycle.

## React Hooks

Hooks are functions that let you "hook into" React state and lifecycle features from function components. The most commonly used hooks are:

1. **useState**: Adds state to functional components
2. **useEffect**: Performs side effects in functional components
3. **useContext**: Subscribes to React context
4. **useReducer**: Manages more complex state logic
5. **useCallback**: Memoizes callback functions
6. **useMemo**: Memoizes computed values

## useState Hook

The useState hook is the most basic hook for managing state in functional components.
        `,
        codeExample: `
import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function Counter() {
  // Declare a state variable 'count' with initial value 0
  const [count, setCount] = useState(0);
  
  return (
    <View style={styles.container}>
      <Text style={styles.countText}>Count: {count}</Text>
      <View style={styles.buttonContainer}>
        <Button 
          title="Increment" 
          onPress={() => setCount(count + 1)} 
        />
        <Button 
          title="Decrement" 
          onPress={() => setCount(count - 1)} 
          color="#841584"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  countText: {
    fontSize: 24,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '60%',
  },
});
        `,
        quiz: {
          id: '1-3-quiz',
          questions: [
            {
              id: '1-3-q1',
              type: 'multiple-choice',
              question: 'What is the purpose of the useState hook?',
              options: [
                'To add state to functional components',
                'To create class components',
                'To style components',
                'To navigate between screens'
              ],
              correctAnswer: 'To add state to functional components',
              explanation: 'The useState hook allows functional components to have state variables, which was previously only possible in class components.'
            },
            {
              id: '1-3-q2',
              type: 'error-detection',
              question: 'What is wrong with this code?',
              code: `
import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

function Counter() {
  const [count, setCount] = useState(0);
  
  return (
    <View>
      <Text>Count: {count}</Text>
      <Button 
        title="Increment" 
        onPress={setCount(count + 1)} 
      />
    </View>
  );
}
              `,
              correctAnswer: 'onPress={setCount(count + 1)} will call the function immediately instead of on press',
              explanation: 'The onPress handler is calling setCount immediately rather than when the button is pressed. It should be onPress={() => setCount(count + 1)}.'
            },
            {
              id: '1-3-q3',
              type: 'fill-in-blank',
              question: 'Complete the code to create a toggle switch using useState:',
              code: `
import React, { ___1___ } from 'react';
import { View, Switch, Text } from 'react-native';

export default function ToggleSwitch() {
  const [isEnabled, ___2___] = ___1___(false);
  
  const toggleSwitch = () => {
    ___2___(previousState => !previousState);
  };
  
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Switch
        trackColor={{ false: "#767577", true: "#81b0ff" }}
        thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"}
        onValueChange={___3___}
        value={___4___}
      />
      <Text style={{ marginLeft: 10 }}>
        {isEnabled ? 'ON' : 'OFF'}
      </Text>
    </View>
  );
}`,
              blanks: [
                { id: '1', correctAnswer: 'useState' },
                { id: '2', correctAnswer: 'setIsEnabled' },
                { id: '3', correctAnswer: 'toggleSwitch' },
                { id: '4', correctAnswer: 'isEnabled' }
              ],
              explanation: 'This code creates a toggle switch component using the useState hook. The state variable isEnabled tracks whether the switch is on or off, and setIsEnabled is the function that updates this state. The toggleSwitch function is called when the switch is toggled, and it updates the state by inverting the previous value.'
            }
          ]
        }
      }
    ]
  },
  {
    id: '2',
    title: 'Navigation in React Native',
    description: 'Learn how to implement navigation in your React Native apps',
    image: 'https://images.unsplash.com/photo-1526498460520-4c246339dccb?q=80&w=2070&auto=format&fit=crop',
    duration: '1.5 hours',
    level: 'intermediate',
    lessons: [
      {
        id: '2-1',
        title: 'Introduction to React Navigation',
        content: `
# Introduction to React Navigation

Navigation is a critical part of any mobile application. React Navigation is a popular library that provides a way to navigate between different screens in your React Native app.

## Key Concepts

- **Stack Navigator**: Provides a way for your app to transition between screens where each new screen is placed on top of a stack
- **Tab Navigator**: Lets you switch between different screens by tapping on a tab
- **Drawer Navigator**: Provides a side menu that can be opened by swiping from the edge of the screen

## Getting Started

To use React Navigation, you need to install the core package and the navigators you want to use.
        `,
        codeExample: `
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, Button } from 'react-native';

// Define your screens
function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Home Screen</Text>
      <Button
        title="Go to Details"
        onPress={() => navigation.navigate('Details')}
      />
    </View>
  );
}

function DetailsScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Details Screen</Text>
    </View>
  );
}

// Create a stack navigator
const Stack = createStackNavigator();

// Set up the navigation structure
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Details" component={DetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
        `,
        quiz: {
          id: '2-1-quiz',
          questions: [
            {
              id: '2-1-q1',
              type: 'multiple-choice',
              question: 'What is the purpose of NavigationContainer in React Navigation?',
              options: [
                'It manages the navigation state and links the navigator to the app environment',
                'It creates a new screen in the navigation stack',
                'It provides styling for navigation components',
                'It handles deep linking in the application'
              ],
              correctAnswer: 'It manages the navigation state and links the navigator to the app environment',
              explanation: 'NavigationContainer is a component that manages the navigation state and links the navigator to the app environment. It must wrap all navigator components.'
            },
            {
              id: '2-1-q2',
              type: 'code-completion',
              question: 'Complete the code to navigate to the Profile screen with a userId parameter:',
              code: `
function HomeScreen({ navigation }) {
  return (
    <View>
      <Button
        title="Go to Profile"
        onPress={() => navigation.____('____', { userId: '123' })}
      />
    </View>
  );
}
              `,
              correctAnswer: ['navigate', 'Profile'],
              explanation: 'To navigate to another screen with parameters, use navigation.navigate(routeName, params).'
            },
            {
              id: '2-1-q3',
              type: 'fill-in-blank',
              question: 'Complete the code to set up a Tab Navigator:',
              code: `
import React from 'react';
import { ___1___ } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { HomeScreen, SettingsScreen, ProfileScreen } from './screens';

const Tab = ___2___();

export default function App() {
  return (
    <___1___>
      <Tab.Navigator>
        <Tab.___3___ name="Home" component={___4___} />
        <Tab.___3___ name="Settings" component={SettingsScreen} />
        <Tab.___3___ name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </___1___>
  );
}`,
              blanks: [
                { id: '1', correctAnswer: 'NavigationContainer' },
                { id: '2', correctAnswer: 'createBottomTabNavigator' },
                { id: '3', correctAnswer: 'Screen' },
                { id: '4', correctAnswer: 'HomeScreen' }
              ],
              explanation: 'This code sets up a bottom tab navigator with three screens: Home, Settings, and Profile. The NavigationContainer is the parent component that manages navigation state, and Tab.Screen components define each screen in the tab navigator.'
            }
          ]
        }
      }
    ]
  },
  {
    id: '3',
    title: 'Styling in React Native',
    description: 'Master the art of styling your React Native applications',
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=1974&auto=format&fit=crop',
    duration: '1 hour',
    level: 'beginner',
    lessons: [
      {
        id: '3-1',
        title: 'StyleSheet and Inline Styles',
        content: `
# StyleSheet and Inline Styles

Styling in React Native is done using JavaScript. The StyleSheet API provides an abstraction layer similar to CSS stylesheets.

## Inline Styles

You can style React Native components by passing a style object to the style prop:

\`\`\`jsx
<View style={{ backgroundColor: 'blue', padding: 10 }}>
  <Text style={{ color: 'white', fontSize: 16 }}>Hello, World!</Text>
</View>
\`\`\`

## StyleSheet API

The StyleSheet API is the recommended way to style your components:

\`\`\`jsx
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'blue',
    padding: 10,
  },
  text: {
    color: 'white',
    fontSize: 16,
  },
});

// Then use it like:
<View style={styles.container}>
  <Text style={styles.text}>Hello, World!</Text>
</View>
\`\`\`

## Benefits of StyleSheet

1. **Performance**: StyleSheet objects are processed once and not on every render
2. **Validation**: StyleSheet validates styles at creation time
3. **Organization**: Keeps styles separate from component logic
        `,
        codeExample: `
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function StyledComponent() {
  return (
    <View style={styles.container}>
      <View style={styles.box}>
        <Text style={styles.title}>Welcome</Text>
        <Text style={styles.subtitle}>Learn React Native Styling</Text>
      </View>
      
      <View style={[styles.box, styles.secondaryBox]}>
        <Text style={[styles.text, styles.boldText]}>
          You can combine styles using arrays
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  box: {
    padding: 15,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  secondaryBox: {
    backgroundColor: '#e0f7fa',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
  },
  text: {
    fontSize: 14,
    color: '#333',
  },
  boldText: {
    fontWeight: 'bold',
  },
});
        `,
        quiz: {
          id: '3-1-quiz',
          questions: [
            {
              id: '3-1-q1',
              type: 'multiple-choice',
              question: 'What is the main advantage of using StyleSheet.create() over inline styles?',
              options: [
                'Better performance as styles are processed once',
                'More styling options are available',
                'It allows for CSS-like selectors',
                'It enables the use of media queries'
              ],
              correctAnswer: 'Better performance as styles are processed once',
              explanation: 'StyleSheet.create() processes styles once when the component loads, rather than on every render, which improves performance.'
            },
            {
              id: '3-1-q2',
              type: 'true-false',
              question: 'In React Native, you can use CSS files directly like in web development.',
              correctAnswer: 'false',
              explanation: 'React Native does not use CSS files. Instead, it uses JavaScript objects for styling that resemble CSS but with camelCase property names and no selectors.'
            },
            {
              id: '3-1-q3',
              type: 'fill-in-blank',
              question: 'Complete the code to create a styled button component:',
              code: `
import React from 'react';
import { TouchableOpacity, Text, ___1___ } from 'react-native';

export default function StyledButton({ title, onPress }) {
  return (
    <TouchableOpacity style={___2___.button} onPress={onPress}>
      <Text style={styles.buttonText}>{title}</Text>
    </TouchableOpacity>
  );
}

const ___2___ = ___1___.create({
  button: {
    backgroundColor: '#007bff',
    ___3___: 10,
    paddingVertical: 12,
    paddingHorizontal: 20,
    ___4___: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});`,
              blanks: [
                { id: '1', correctAnswer: 'StyleSheet' },
                { id: '2', correctAnswer: 'styles' },
                { id: '3', correctAnswer: 'borderRadius' },
                { id: '4', correctAnswer: 'borderRadius' }
              ],
              explanation: 'This code creates a styled button component using StyleSheet.create() to define the styles. The button has a blue background color, rounded corners (borderRadius), and padding. The text is white, bold, and has a font size of 16.'
            }
          ]
        }
      }
    ]
  }
];