export const motivationalQuotes = [
  "The only way to learn programming is by programming. - Richard Stallman",
  "First, solve the problem. Then, write the code. - John Johnson",
  "Code is like humor. When you have to explain it, it's bad. - Cory House",
  "The best error message is the one that never shows up. - Thomas Fuchs",
  "It's not a bug – it's an undocumented feature. - Anonymous",
  "Programming isn't about what you know; it's about what you can figure out. - Chris Pine",
  "The most disastrous thing that you can ever learn is your first programming language. - Alan Kay",
  "Simplicity is the soul of efficiency. - Austin Freeman",
  "Make it work, make it right, make it fast. - Kent Beck",
  "Any fool can write code that a computer can understand. Good programmers write code that humans can understand. - Martin Fowler",
  "Experience is the name everyone gives to their mistakes. - Oscar Wilde",
  "The best way to predict the future is to implement it. - David Heinemeier Hansson",
  "Sometimes it pays to stay in bed on Monday, rather than spending the rest of the week debugging Monday's code. - Dan Salomon",
  "Perfection is achieved not when there is nothing more to add, but rather when there is nothing more to take away. - Antoine de Saint-Exupery",
  "The most important property of a program is whether it accomplishes the intention of its user. - C.A.R. Hoare"
];