import { Resource } from '@/types';

export const resources: Resource[] = [
  {
    id: '1',
    title: 'React Native Crash Course',
    description: 'Learn the basics of React Native in this comprehensive crash course',
    url: 'https://www.youtube.com/watch?v=Hf4MJH0jDb4',
    platform: 'youtube',
    tags: ['beginner', 'components', 'props', 'state'],
    image: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=1974&auto=format&fit=crop'
  },
  {
    id: '2',
    title: 'React Native - The Practical Guide',
    description: 'Dive into React Native, Redux, Hooks & more by building real apps',
    url: 'https://www.udemy.com/course/react-native-the-practical-guide/',
    platform: 'udemy',
    tags: ['comprehensive', 'redux', 'hooks', 'navigation'],
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: '3',
    title: 'React Native Hooks Tutorial',
    description: 'Learn how to use React Hooks in your React Native applications',
    url: 'https://www.youtube.com/watch?v=iMCM1NceGJY',
    platform: 'youtube',
    tags: ['hooks', 'useState', 'useEffect', 'intermediate'],
    image: 'https://images.unsplash.com/photo-1581276879432-15e50529f34b?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: '4',
    title: 'React Native Navigation Tutorial',
    description: 'Master navigation in React Native with React Navigation',
    url: 'https://www.youtube.com/watch?v=nQVCkqvU1uE',
    platform: 'youtube',
    tags: ['navigation', 'stack', 'tabs', 'drawer'],
    image: 'https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: '5',
    title: 'React Native with TypeScript',
    description: 'Learn how to use TypeScript with React Native for type-safe code',
    url: 'https://www.youtube.com/watch?v=1oEBSXlqymI',
    platform: 'youtube',
    tags: ['typescript', 'types', 'interfaces', 'advanced'],
    image: 'https://images.unsplash.com/photo-1607799279861-4dd421887fb3?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: '6',
    title: 'React Native Animation Tutorial',
    description: 'Create beautiful animations in React Native with Animated API',
    url: 'https://www.youtube.com/watch?v=ZiSN9uik6OY',
    platform: 'youtube',
    tags: ['animation', 'animated', 'transitions', 'advanced'],
    image: 'https://images.unsplash.com/photo-1550063873-ab792950096b?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: '7',
    title: 'React Native State Management with Context API',
    description: 'Learn how to manage state in React Native using Context API',
    url: 'https://www.youtube.com/watch?v=sBws8MSXN7A',
    platform: 'youtube',
    tags: ['state', 'context', 'hooks', 'intermediate'],
    image: 'https://images.unsplash.com/photo-1555099962-4199c345e5dd?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: '8',
    title: 'React Native UI Libraries',
    description: 'Explore popular UI libraries for React Native development',
    url: 'https://www.youtube.com/watch?v=DftsReyhz2Q',
    platform: 'youtube',
    tags: ['ui', 'components', 'libraries', 'design'],
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=1974&auto=format&fit=crop'
  }
];